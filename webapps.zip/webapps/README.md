# Web Apps for Twister OS

This will be a growing collection of web apps added for fun

# To Update

- Web Apps will automatically grab any new updates made to it
