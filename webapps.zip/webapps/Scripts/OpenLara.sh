#!/bin/bash
chromium-browser %U --user-data-dir=/home/pi/.config/webapps/OpenLara --app=http://xproger.info/projects/OpenLara/  --window-size=850,550
