#!/bin/bash
chromium-browser %U --user-data-dir=/home/pi/.config/webapps/treasurearena --app=http://titotu.io/embed/treasurearena-com  --window-size=1024,768 
