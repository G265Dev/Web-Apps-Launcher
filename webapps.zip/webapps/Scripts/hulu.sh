#!/bin/bash
chromium-browser %U --user-agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36" --user-data-dir=/home/pi/.config/webapps/Hulu --app=https://www.hulu.com/hub/home  --window-size=1200,800 
