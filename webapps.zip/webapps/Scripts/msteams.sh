#!/bin/bash
chromium-browser %U --user-data-dir=/home/pi/.config/webapps/MSTeams --app=https://teams.microsoft.com/  --window-size=600,800
