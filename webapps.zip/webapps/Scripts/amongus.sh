#!/bin/bash
chromium-browser %U --user-data-dir=/home/pi/.config/webapps/AmongUS --app=http://titotu.io/embed/among-us-freeplay  --window-size=1500,900 
