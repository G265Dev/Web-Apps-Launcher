#!/bin/bash
chromium-browser %U --user-data-dir=/home/pi/.config/webapps/Diablo --app=https://d07riv.github.io/diabloweb/  --window-size=800,600 
