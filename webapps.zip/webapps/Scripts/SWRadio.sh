#!/bin/bash
chromium-browser --user-agent="Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.90 Safari/537.36" --user-data-dir=/home/pi/.config/webapps/SWRadio --app=https://www.chilton.com/R8/receiver.html --window-size=1000,550 
