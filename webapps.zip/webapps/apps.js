function openBflix() {
  myWindow = window.open("", "", "width=1500, height=900");
  myWindow.location.href = "http://bflix.to";
}

function openYoutube() {
  myWindow = window.open("", "", "width=1200, height=800");
  myWindow.location.href = "http://youtube.com";
}

function openMessenger() {
  myWindow = window.open("", "", "width=500, height=800");
  myWindow.location.href = "http://messenger.com";
}

function openReddit() {
  myWindow = window.open("", "", "width=600, height=900");
  myWindow.location.href = "http://reddit.com";
}

function openAmongUS() {
  myWindow = window.open("", "", "width=1200, height=900");
  myWindow.location.href = "http://titotu.io/embed/among-us-freeplay";
}

function openEntanglement() {
  myWindow = window.open("", "", "width=1200, height=800");
  myWindow.location.href = "http://entanglement.gopherwoodstudios.com/en-US-index.html";
}

function openKiwiIRC() {
  myWindow = window.open("", "", "width=1200, height=768");
  myWindow.location.href = "https://kiwiirc.com/nextclient/";
}

function openDiablo() {
  myWindow = window.open("", "", "width=800, height=600");
  myWindow.location.href = "https://d07riv.github.io/diabloweb/";
}

function openEntanglement() {
  myWindow = window.open("", "", "width=1200, height=800");
  myWindow.location.href = "http://entanglement.gopherwoodstudios.com/en-US-index.html";
}

function openCandyBubble() {
  myWindow = window.open("", "", "width=1200, height=768");
  myWindow.location.href = "https://play.famobi.com/candy-bubble";
}

function openLara() {
  myWindow = window.open("", "", "width=850, height=550");
  myWindow.location.href = "http://xproger.info/projects/OpenLara/";
}

function openNetflix() {
  myWindow = window.open("", "", "width=1200, height=800");
  myWindow.location.href = "https://www.netflix.com/browse";
}

function openHulu() {
  myWindow = window.open("", "", "width=1200, height=800");
  myWindow.location.href = "https://www.hulu.com/hub/home";
}

function openPluto() {
  myWindow = window.open("", "", "width=1500, height=900");
  myWindow.location.href = "https://pluto.tv/live-tv";
}

function openSpotify() {
  myWindow = window.open("", "", "width=1200, height=600");
  myWindow.location.href = "https://open.spotify.com/";
}

function openRedax() {
  myWindow = window.open("", "", "width=600, height=850");
  myWindow.location.href = "https://redaxsounds.netlify.app/";
}

function openSWRadio() {
    myWindow = window.open("", "", "width=1000, height=550");
    myWindow.location.href = "https://www.chilton.com/R8/receiver.html";
}

function openTwitter() {
    myWindow = window.open("", "", "width=600, height=800");
    myWindow.location.href = "https://twitter.com/home";
}

function openBQuest() {
    myWindow = window.open("", "", "width=1200, height=768");
    myWindow.location.href = "http://browserquest.herokuapp.com/";
}

function openEmpire() {
    myWindow = window.open("", "", "width=1500, height=900");
    myWindow.location.href = "https://empire.goodgamestudios.com/";
}

function openFallBros() {
    myWindow = window.open("", "", "width=1500, height=900");
    myWindow.location.href = "http://titotu.io/embed/fall-bros";
}

function openKrunker() {
  myWindow = window.open("", "", "width=1200, height=800");
  myWindow.location.href = "https://krunker.io/";
}

function openMahjong() {
  myWindow = window.open("", "", "width=1200, height=900");
  myWindow.location.href = "https://play.famobi.com/mahjong-3d";
}

function openMars() {
  myWindow = window.open("", "", "width=1500, height=900");
  myWindow.location.href = "https://play.mars-tomorrow.com/";
}

function openMinecraft() {
  myWindow = window.open("", "", "width=1024, height=768");
  myWindow.location.href = "https://classic.minecraft.net/";
}

function openMiniroyale() {
  myWindow = window.open("", "", "width=1200, height=800");
  myWindow.location.href = "https://miniroyale2.io/";
}

function openSkribbl() {
  myWindow = window.open("", "", "width=1200, height=768");
  myWindow.location.href = "https://skribbl.io/";
}

function openTreasureArena() {
  myWindow = window.open("", "", "width=1024, height=768");
  myWindow.location.href = "http://titotu.io/embed/treasurearena-com";
}

function openVaporboy() {
  myWindow = window.open("", "", "width=1000, height=800");
  myWindow.location.href = "https://vaporboy.net/";
}

function openAnime() {
  myWindow = window.open("", "", "width=1500, height=900");
  myWindow.location.href = "https://animesuge.to/";
}

function openDiscord() {
  myWindow = window.open("", "", "width=1200, height=768");
  myWindow.location.href = "https://discord.com/login";
}

function openElement() {
  myWindow = window.open("", "", "width=1200, height=768");
  myWindow.location.href = "https://app.element.io/";
}

function openInstagram() {
  myWindow = window.open("", "", "width=600, height=800");
  myWindow.location.href = "https://www.instagram.com/";
}

function openTeams() {
  myWindow = window.open("", "", "width=600, height=800");
  myWindow.location.href = "https://teams.microsoft.com/";
}

function openSkype() {
  myWindow = window.open("", "", "width=600, height=800");
  myWindow.location.href = "https://web.skype.com/";
}

function openTelegram() {
  myWindow = window.open("", "", "width=1200, height=768");
  myWindow.location.href = "https://web.telegram.org/";
}

function openTiktok() {
  myWindow = window.open("", "", "width=600, height=800");
  myWindow.location.href = "https://www.tiktok.com/foryou/";
}

function openWhat() {
  myWindow = window.open("", "", "width=1000, height=768");
  myWindow.location.href = "https://web.whatsapp.com/";
}

function openBandlab() {
  myWindow = window.open("", "", "width=1200, height=768");
  myWindow.location.href = "https://www.bandlab.com/feed";
}

function openGmail() {
  myWindow = window.open("", "", "width=1500, height=900");
  myWindow.location.href = "https://mail.google.com/mail/u/0/#inbox";
}

function openTranslate() {
  myWindow = window.open("", "", "width=600, height=800");
  myWindow.location.href = "https://translate.google.com/";
}

function openOutlook() {
  myWindow = window.open("", "", "width=1500, height=900");
  myWindow.location.href = "https://outlook.office.com/mail/";
}

function openZoom() {
  myWindow = window.open("", "", "width=600, height=800");
  myWindow.location.href = "https://pwa.zoom.us/wc";
}

function openDiscUS() {
  myWindow = window.open("", "", "width=980, height=560");
  myWindow.location.href = "http://v6p9d9t4.ssl.hwcdn.net/html/3012712/index.html";
}

function openScratch() {
  myWindow = window.open("", "", "width=1500, height=900");
  myWindow.location.href = "https://scratch.mit.edu/projects/editor/";
}

function openEarth() {
  myWindow = window.open("", "", "width=600, height=900");
  myWindow.location.href = "https://earth.google.com/web/";
}

function openSwoop() {
  myWindow = window.open("", "", "width=1200, height=768");
  myWindow.location.href = "https://s3-eu-west-1.amazonaws.com/apps.playcanvas.com/R2axJfsc/index.html";
}

function openDoodle() {
  myWindow = window.open("", "", "width=450, height=600");
  myWindow.location.href = "https://funhtml5games.com/doodlejump/index.html";
}

function openAlchemy2() {
  myWindow = window.open("", "", "width=1024, height=768");
  myWindow.location.href = "https://littlealchemy2.com/";
}

function openWolfram() {
  myWindow = window.open("", "", "width=1024, height=768");
  myWindow.location.href = "https://www.wolframalpha.com/";
}

function openProton() {
  myWindow = window.open("", "", "width=1200, height=768");
  myWindow.location.href = "https://mail.protonmail.com/inbox";
}

function openXfinity() {
  myWindow = window.open("", "", "width=1200, height=800");
  myWindow.location.href = "https://www.xfinity.com/stream/listings/tve";
}

function openPixlr() {
  myWindow = window.open("", "", "width=1200, height=800");
  myWindow.location.href = "https://pixlr.com/e/";
}

function openBejeweled() {
  myWindow = window.open("", "", "width=730, height=550");
  myWindow.location.href = "http://q10games.com/bejeweled-html5/";
}

function openHubs() {
  myWindow = window.open("", "", "width=1024, height=768");
  myWindow.location.href = "https://hubs.mozilla.com/AP94aru/pretty-violet-huddle/";
}

function openPetra() {
  myWindow = window.open("", "", "width=1024, height=768");
  myWindow.location.href = "https://www.google.com/maps/about/behind-the-scenes/streetview/treks/petra/#explore-overview";
}

function openQuake() {
  myWindow = window.open("", "", "width=1024, height=768");
  myWindow.location.href = "http://www.quakejs.com/";
}

function openLoadrunner() {
  myWindow = window.open("", "", "width=1024, height=768");
  myWindow.location.href = "http://loderunnerwebgame.com/game/";
}

function openNymble() {
  myWindow = window.open("", "", "width=480, height=852");
  myWindow.location.href = "http://v6p9d9t4.ssl.hwcdn.net/html/3110712/index.html";
}

function openSolitaire() {
  myWindow = window.open("", "", "width=1200, height=768");
  myWindow.location.href = "https://worldofsolitaire.com/";
}

function openBadland() {
  myWindow = window.open("", "", "width=1024, height=768");
  myWindow.location.href = "https://play.gamepix.com/badland/embed?sid=110901&rgx=1&gpxref=play.gamepix.com&utm_source=play.gamepix.com&utm_medium=publisherV3";
}

function openCutTheRope() {
  myWindow = window.open("", "", "width=1024, height=768");
  myWindow.location.href = "https://play.gamepix.com/cut-the-rope/embed?sid=110638&lang=en&rgx=1&gpxref=direct&utm_source=direct&utm_medium=publisherV3";
}

function openGodOfLight() {
  myWindow = window.open("", "", "width=1024, height=768");
  myWindow.location.href = "https://play.gamepix.com/god-of-light/embed?sid=110901&rgx=1&gpxref=play.gamepix.com&utm_source=play.gamepix.com&utm_medium=publisherV3";
}

function openFreddy() {
  myWindow = window.open("", "", "width=1024, height=768");
  myWindow.location.href = "https://gamasexual.com/c/f/g/five-nights-at-freddys/";
}

function openDisney() {
  myWindow = window.open("", "", "width=1200, height=800");
  myWindow.location.href = "https://www.disneyplus.com/";
}

function openBitwarden() {
  myWindow = window.open("", "", "width=800, height=600");
  myWindow.location.href = "https://vault.bitwarden.com/#/vault";
}

function openEvernote() {
  myWindow = window.open("", "", "width=1200, height=800");
  myWindow.location.href = "https://www.evernote.com/client/web";
}

function openPocket() {
  myWindow = window.open("", "", "width=800, height=600");
  myWindow.location.href = "https://getpocket.com/my-list";
}

function openCryptovoxels() {
  myWindow = window.open("", "", "width=800, height=600");
  myWindow.location.href = "https://www.cryptovoxels.com/play";
}

function openTwitch() {
  myWindow = window.open("", "", "width=1200, height=800");
  myWindow.location.href = "https://www.twitch.tv/";
}

function openiHeart() {
  myWindow = window.open("", "", "width=1200, height=800");
  myWindow.location.href = "https://www.iheart.com/live";
}

function openRadioGarden() {
  myWindow = window.open("", "", "width=800, height=600");
  myWindow.location.href = "http://radio.garden/";
}

function openCrackle() {
  myWindow = window.open("", "", "width=1200, height=800");
  myWindow.location.href = "https://www.crackle.com/";
}

function openTetrio() {
  myWindow = window.open("", "", "width=1200, height=900");
  myWindow.location.href = "https://tetr.io/";
}

function openLiero() {
  myWindow = window.open("", "", "width=1200, height=900");
  myWindow.location.href = "https://www.webliero.com/";
}

function openFlappy() {
  myWindow = window.open("", "", "width=600, height=800");
  myWindow.location.href = "https://playcanv.as/p/2OlkUaxF/";
}

function openUnlocked() {
  myWindow = window.open("", "", "width=1200, height=900");
  myWindow.location.href = "https://unlocked.conneath.gq/games/";
}

function openBlockbench() {
  myWindow = window.open("", "", "width=1200, height=900");
  myWindow.location.href = "https://web.blockbench.net/";
}

function openDocs() {
  myWindow = window.open("", "", "width=1500, height=900");
  myWindow.location.href = "https://docs.google.com/document/u/0/";
}

function open96() {
  myWindow = window.open("", "", "width=1080, height=1920");
  myWindow.location.href = "https://windows96.net";
}

function openSDR() {
  myWindow = window.open("", "", "width=1200, height=900");
  myWindow.location.href = "http://kiwisdr.com/public/";
}

function openRoblox() {
  myWindow = window.open("", "", "width=1200, height=900");
  myWindow.location.href = "https://now.gg/apps/roblox-corporation/5349/roblox.html";
}

